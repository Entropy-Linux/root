  __________________________________________
 /                                          \
 |   _____       _                          |
 |  | ____|_ __ | |_ _ __ ___  _ __  _   _  |
 |  |  _| | '_ \| __| '__/ _ \| '_ \| | | | |
 |  | |___| | | | |_| | | (_) | |_) | |_| | |
 |  |_____|_| |_|\__|_|  \___/| .__/ \__, | |
 |                            |_|    |___/  |
 |        _     _                           |
 |       | |   (_)_ __  _   ___  __         |
 |       | |   | | '_ \| | | \ \/ /         |
 |       | |___| | | | | |_| |>  <          |
 |       |_____|_|_| |_|\__,_/_/\_\         |
 |                                          |
 \                                          /
  ------------------------------------------
     \
      \
          .--.
         |x_x |   [Szmelc.INC]       
         |:_/ |  
        //   \ \   ~ [sx66] ~
       (|     | )
      /'\_   _/`\
      \___)=(___/


 == [ABOUT] ==
- [Entropy] is an distro based of MX-Minimal.
   (if you want, feel free to call it a respin.)
   What makes the difference, is `szmelc`
   (szmelc ~ simple software written mostly in shell, by Szmelc.INC)

 = [Note] =
  This project is home made primarly by a single developer, with some help from friends.
  Thus patience with some degree of understanding how systems work is highly advised.

 == [FEATURES] ==
- `szmelc` ~ use this command to bring full list of features




