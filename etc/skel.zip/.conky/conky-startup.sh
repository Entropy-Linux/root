#!/bin/sh

sleep 20s
killall -u $(id -nu) conky 2>/dev/null
cd "$HOME/.conky/Entropy"
conky -c "$HOME/.conky/Entropy/Entropy" &
exit 0
