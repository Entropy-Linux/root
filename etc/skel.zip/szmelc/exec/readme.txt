Tutaj wrzuć swoje programy portable i launchery typu
.AppImage .deb .sh oraz inne pliki executable
