Dostepne komendy:
- apprun
- bashton
- brigx
- cvi
- sxdlp
- ecrx
- fget
- findit
- jebnijbasemsynu
- logouttty
- mtrim
- polishcat
- pwr
- rgxkill
- setch
- usi
- xloop
- xsplit666
- xtime
- xttx
- ytest

 UWAGA! Niektore skrypty mogą wymagać doinstalowania dodatkowych paczek.
 
 Aktualizator szmelcu: szmelc-update
